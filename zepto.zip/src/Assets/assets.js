import searchIcon from "./Icons/searchIcon.svg"
import bagIcon from "./Icons/bagIcon.svg"
import download from "./Icons/download.jpeg"
import cross from "./Icons/croos.svg";
export {
    searchIcon,
    bagIcon,
    download,
    cross
}